
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart1 {
    
    TestPart1() {
        // put your constructor code here to initialise any class fields           
    }
    
    public void run() {
        System.out.println("Part1 started --- Tests for the MCQ class\n");
        // put all your code here to work with your MCQ class
        MCQ mcq = new MCQ();
        System.out.println("\nPart1 completed");
        System.out.println("==============================================\n");
    }
    
    // if you need some class fields so put them here
}
