
package dsacw;

/**
 *
 * @author jde
 * 
 * remember this class should implement the IADTMCQ interface
 */
public class MCQList  {    

    MCQList() {
        // put your constructor code here to initialise any class fields           
    }    
    
    // you need some getters and setters so put them here
}
