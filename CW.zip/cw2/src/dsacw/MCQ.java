
package dsacw;

/**
 *
 * @author jde
 */
public class MCQ  {
    

    MCQ() {
        // put your constructor code here to initialise any class fields           
    }
        
    // you need some class fields so put them here
}
