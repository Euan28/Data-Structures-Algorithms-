
package dsacw;

/**
 *
 * @author jde
 */
public class MCQBST  {    

    MCQBST() {
        // put your constructor code here to initialise any class fields etc
    }
        
    // put your class members here
}
