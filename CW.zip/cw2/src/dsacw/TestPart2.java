
package dsacw;

/**
 *
 * @author jde
 */
public class TestPart2 {

    TestPart2() {
        // put your constructor code here to initialise any class stuff           
    }
    
    public void run() {
        System.out.println("Part2 started --- Tests for the MCQList class\n");
        System.out.println(" remember to implement the IADTMCQ interface as part of the MCQList\n");
        // put your code here to work with the MCQList class that you built
        MCQList mcqList = new MCQList();
        System.out.println("\nPart2 completed");
        System.out.println("==============================================\n");
    }
    
    // if you need some class fields you can put them here
}
